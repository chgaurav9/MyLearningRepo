package com.spotify.oauth2.utils;

public class DummyClass {

    public void dummy(){
        System.out.println("dummy");
    }
}
